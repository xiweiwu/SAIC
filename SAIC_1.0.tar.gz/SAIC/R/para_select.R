para_select <-
function(data,cluster,pvalue, number, method="kmeans", process){
  require(parallel)
  result_all <- mclapply(1:length(cluster), function(i) {
    print(paste("cluster number",cluster[i],"starts..."))
    result1 <- array(dim=length(pvalue))
	for (j in 1:length(pvalue)){
      result <- cluster_analysis(data = data,cluster_number = cluster[i],pvalue = pvalue[j], number, method=method)
      if(!is.null(result)) {
		result1[j] <- result$dbScore
      } else {
		result1[j] <- paste(NA,result$dbScore,sep=".")
	  }
    }
	return(result1)
  }, mc.cores=min(process, length(cluster)))
  result_all <- do.call("rbind",result_all)
  colnames(result_all) <- pvalue; row.names(result_all) <- cluster
  return(result_all)
}
